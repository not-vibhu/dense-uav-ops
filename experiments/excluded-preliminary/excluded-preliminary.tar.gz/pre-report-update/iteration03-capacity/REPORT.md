# Mixed fleet safety comparison

Completed **96 / 96** reproducible runs. Fleet sizes: [10, 50]; cooperative fractions: [0.5, 1.0]; fixed-wing fraction: 0.4. Every catalog scenario was evaluated only if listed in the manifest.

Discovery choice: **mappo**. Stable on holdout: **False**. Empirical safety gate passed: **False**.

The gate requires zero participating-aircraft collisions, zero obstacle collisions, zero volume exits, zero unresolved barrier steps or failed predictive libraries, zero vehicle-limit violations, and at least 70% participating goal reach on holdout. A gate pass would still be a finite-suite result, not a flight safety proof.

## Holdout results

| Controller | Collision runs | Obstacle runs | Volume exit runs | Separation exposure | Goal reach | Unresolved control steps |
|---|---:|---:|---:|---:|---:|---:|
| predictive | 25.0% | 0.0% | 37.5% | 0.01% | 74.0% | 10992 |
| imitation | 25.0% | 0.0% | 43.8% | 0.01% | 69.6% | 10867 |
| mappo | 25.0% | 0.0% | 43.8% | 0.01% | 70.1% | 10562 |

Collision run rates count encounters involving at least one equipped participant. Legacy–legacy collision pairs are published separately and are not attributed to control authority the system does not have. Zero-cooperation runs are included in raw results but excluded from controller ranking.

Separation exposure is the fraction of active participating pair-time steps whose continuous swept trajectory crossed the 10 m boundary. A touched step counts its entire duration, so this is an upper step-based exposure measure. Collision thresholds use the sum of physical radii. Minimum distance away from threat thresholds is a conservative chord lower bound.

## Interpretation

**No configuration cleared the safety gate.** The discovery choice is a lower-risk research candidate under the published lexicographic ordering, not a deployment recommendation. Inspect failed scenarios and unresolved constraints; lower demand, better sensing, route redesign and admission control may be required.

## Coverage and provenance

Discovery seeds: [5000]; holdout seeds: [6000]. Step: 0.2 s; encounter duration: 36.0 s. Source SHA-256: `c64d3bb96816499f0903e412c77b5d3a97b7b12236735403395fbdfbc4ed6fa5`.

The simulator uses a common synthetic regional feed, approximate finite-projection barriers, idealized mixed point-mass dynamics and absorbing goals. It does not implement authenticated ASTM messaging, an exact ORCA or QP solver, verified backup invariance, RF propagation, impact/wreckage physics, or aircraft aerodynamic certification. Intentional out-of-bounds faults are separated in summary.json. Predictive preferences may be optimized by evolutionary search; no neural MARL policy is trained. Goal reach includes diagnostic trajectories continuing after collisions and is not a successful real mission rate.

See manifest.json, runs.jsonl, results.json and summary.json for every configuration and outcome. Reported timing is measured on this host, includes Python overhead, and cannot establish an onboard real-time deadline.
